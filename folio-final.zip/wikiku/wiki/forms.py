from django import forms
from django.contrib.auth.models import User
from slugify import slugify
from .models import Page, Category

INPUT = (
    'w-full px-4 py-2.5 rounded-lg border border-stone-200 bg-white text-stone-800 '
    'placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-stone-400 '
    'focus:border-transparent transition text-sm'
)


class RegisterForm(forms.ModelForm):
    password1 = forms.CharField(
        label='Password',
        widget=forms.PasswordInput(attrs={'class': INPUT, 'placeholder': 'Choose a password'})
    )
    password2 = forms.CharField(
        label='Confirm Password',
        widget=forms.PasswordInput(attrs={'class': INPUT, 'placeholder': 'Repeat password'})
    )

    class Meta:
        model = User
        fields = ['username', 'email']
        widgets = {
            'username': forms.TextInput(attrs={'class': INPUT, 'placeholder': 'Username'}),
            'email': forms.EmailInput(attrs={'class': INPUT, 'placeholder': 'your@email.com'}),
        }

    def clean_email(self):
        email = self.cleaned_data.get('email', '').strip()
        if not email:
            raise forms.ValidationError('Email is required.')
        if User.objects.filter(email=email).exists():
            raise forms.ValidationError('An account with this email already exists.')
        return email

    def clean_password2(self):
        p1 = self.cleaned_data.get('password1', '')
        p2 = self.cleaned_data.get('password2', '')
        if p1 and p2 and p1 != p2:
            raise forms.ValidationError('Passwords do not match.')
        if len(p1) < 8:
            raise forms.ValidationError('Password must be at least 8 characters.')
        return p2

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data['password1'])
        if commit:
            user.save()
        return user


class LoginForm(forms.Form):
    username = forms.CharField(
        max_length=150,
        widget=forms.TextInput(attrs={'class': INPUT, 'placeholder': 'Username', 'autofocus': True})
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={'class': INPUT, 'placeholder': 'Password'})
    )


class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = ['name', 'slug', 'color']
        widgets = {
            'name': forms.TextInput(attrs={'class': INPUT + ' font-medium', 'placeholder': 'Category name...'}),
            'slug': forms.TextInput(attrs={'class': INPUT + ' font-mono', 'placeholder': 'auto-generated'}),
            'color': forms.TextInput(attrs={'type': 'color', 'class': 'w-12 h-10 rounded-lg border border-stone-200 cursor-pointer p-1 bg-white'}),
        }

    def clean_slug(self):
        slug = self.cleaned_data.get('slug', '')
        name = self.cleaned_data.get('name', '')
        return slugify(slug) if slug else slugify(name)


class PageForm(forms.ModelForm):
    categories = forms.ModelMultipleChoiceField(
        queryset=Category.objects.all(),
        required=False,
        widget=forms.CheckboxSelectMultiple,
    )

    class Meta:
        model = Page
        fields = ['title', 'slug', 'content', 'status', 'categories']
        widgets = {
            'title': forms.TextInput(attrs={'class': INPUT + ' font-medium text-base', 'placeholder': 'Page title...'}),
            'slug': forms.TextInput(attrs={'class': INPUT + ' font-mono', 'placeholder': 'auto-generated-from-title'}),
            'status': forms.Select(attrs={'class': 'px-4 py-2.5 rounded-lg border border-stone-200 bg-white text-stone-800 focus:outline-none focus:ring-2 focus:ring-stone-400 focus:border-transparent transition text-sm'}),
            'content': forms.Textarea(attrs={'id': 'markdown-editor', 'rows': 20, 'class': 'w-full'}),
        }

    def clean_slug(self):
        slug = self.cleaned_data.get('slug', '')
        title = self.cleaned_data.get('title', '')
        return slugify(slug) if slug else slugify(title)
