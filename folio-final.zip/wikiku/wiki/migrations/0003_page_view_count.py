from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('wiki', '0002_category_page_categories'),
    ]

    operations = [
        migrations.AddField(
            model_name='page',
            name='view_count',
            field=models.PositiveIntegerField(default=0),
        ),
    ]
