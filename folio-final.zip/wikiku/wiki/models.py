from django.db import models
from django.utils import timezone
import math
import re


class Category(models.Model):
    name = models.CharField(max_length=100, unique=True)
    slug = models.SlugField(max_length=100, unique=True)
    color = models.CharField(max_length=7, default='#78716c')
    created_at = models.DateTimeField(default=timezone.now)

    class Meta:
        ordering = ['name']
        verbose_name_plural = 'Categories'

    def __str__(self):
        return self.name

    def text_color(self):
        hex_color = self.color.lstrip('#')
        r, g, b = int(hex_color[0:2], 16), int(hex_color[2:4], 16), int(hex_color[4:6], 16)
        brightness = (r * 299 + g * 587 + b * 114) / 1000
        return '#1c1917' if brightness > 128 else '#fafaf9'


class Page(models.Model):
    STATUS_DRAFT = 'draft'
    STATUS_PUBLISHED = 'published'
    STATUS_CHOICES = [
        (STATUS_DRAFT, 'Draft'),
        (STATUS_PUBLISHED, 'Published'),
    ]

    title = models.CharField(max_length=255)
    slug = models.SlugField(max_length=255, unique=True)
    content = models.TextField(help_text='Write content in Markdown format')
    status = models.CharField(max_length=20, choices=STATUS_CHOICES, default=STATUS_DRAFT)
    categories = models.ManyToManyField(Category, blank=True, related_name='pages')
    view_count = models.PositiveIntegerField(default=0)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        ordering = ['-updated_at']

    def __str__(self):
        return self.title

    def is_published(self):
        return self.status == self.STATUS_PUBLISHED

    def reading_time(self):
        """Estimate reading time in minutes (avg 200 wpm)."""
        word_count = len(re.sub(r'[#*`>\[\]()-]', '', self.content).split())
        minutes = max(1, math.ceil(word_count / 200))
        return minutes

    def extract_toc(self):
        """Extract headings from markdown for Table of Contents."""
        headings = []
        for line in self.content.splitlines():
            match = re.match(r'^(#{1,3})\s+(.+)', line)
            if match:
                level = len(match.group(1))
                text = match.group(2).strip()
                anchor = re.sub(r'[^a-z0-9\s-]', '', text.lower())
                anchor = re.sub(r'\s+', '-', anchor.strip())
                headings.append({'level': level, 'text': text, 'anchor': anchor})
        return headings
