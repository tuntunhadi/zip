import re
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib.auth.tokens import default_token_generator
from django.contrib.sites.shortcuts import get_current_site
from django.core.mail import send_mail
from django.template.loader import render_to_string
from django.utils.encoding import force_bytes, force_str
from django.utils.http import urlsafe_base64_encode, urlsafe_base64_decode
from django.contrib import messages
from django.db.models import Q, F
from django.http import JsonResponse

from .models import Page, Category
from .forms import PageForm, CategoryForm, LoginForm, RegisterForm


# ─── Helpers ──────────────────────────────────────────────────────────────────

def get_sidebar_context():
    return {
        'all_pages': Page.objects.filter(status=Page.STATUS_PUBLISHED).order_by('title'),
        'all_categories': Category.objects.all(),
        'recent_pages': Page.objects.filter(
            status=Page.STATUS_PUBLISHED
        ).order_by('-updated_at')[:5],
    }


def highlight_query(text, query):
    """Wrap matched query terms in <mark> tags."""
    if not query:
        return text
    pattern = re.compile(re.escape(query), re.IGNORECASE)
    return pattern.sub(lambda m: f'<mark class="bg-amber-200 text-amber-900 rounded px-0.5">{m.group()}</mark>', text)


# ─── Public Views ─────────────────────────────────────────────────────────────

def home(request):
    query = request.GET.get('q', '').strip()
    active_cat = request.GET.get('cat', '').strip()

    pages = Page.objects.filter(status=Page.STATUS_PUBLISHED).prefetch_related('categories')

    if query:
        pages = pages.filter(
            Q(title__icontains=query) | Q(content__icontains=query)
        )

    current_category = None
    if active_cat:
        current_category = get_object_or_404(Category, slug=active_cat)
        pages = pages.filter(categories=current_category)

    # Build search result snippets with highlights
    search_results = []
    if query:
        for page in pages:
            title_hl = highlight_query(page.title, query)
            # Find snippet around keyword in content
            content_plain = re.sub(r'[#*`>\[\]()-]', '', page.content)
            idx = content_plain.lower().find(query.lower())
            if idx >= 0:
                start = max(0, idx - 60)
                end = min(len(content_plain), idx + 120)
                snippet = ('...' if start > 0 else '') + content_plain[start:end] + ('...' if end < len(content_plain) else '')
                snippet_hl = highlight_query(snippet, query)
            else:
                snippet_hl = content_plain[:160] + '...'
            search_results.append({'page': page, 'title_hl': title_hl, 'snippet_hl': snippet_hl})

    ctx = get_sidebar_context()
    ctx.update({
        'pages': pages,
        'query': query,
        'current_category': current_category,
        'search_results': search_results,
    })
    return render(request, 'wiki/home.html', ctx)


def page_detail(request, slug):
    page = get_object_or_404(Page, slug=slug, status=Page.STATUS_PUBLISHED)
    # Increment view count (skip for admin)
    if not request.user.is_authenticated:
        Page.objects.filter(pk=page.pk).update(view_count=F('view_count') + 1)
        page.refresh_from_db()
    toc = page.extract_toc()
    ctx = get_sidebar_context()
    ctx.update({'page': page, 'toc': toc})
    return render(request, 'wiki/page_detail.html', ctx)


def category_detail(request, slug):
    category = get_object_or_404(Category, slug=slug)
    pages = Page.objects.filter(
        status=Page.STATUS_PUBLISHED, categories=category
    ).prefetch_related('categories')
    ctx = get_sidebar_context()
    ctx.update({'category': category, 'pages': pages})
    return render(request, 'wiki/category_detail.html', ctx)


# ─── Auth Views ───────────────────────────────────────────────────────────────

def login_view(request):
    if request.user.is_authenticated:
        return redirect('admin_dashboard')
    form = LoginForm()
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            user = authenticate(
                request,
                username=form.cleaned_data['username'],
                password=form.cleaned_data['password'],
            )
            if user is not None and user.is_staff:
                login(request, user)
                return redirect('admin_dashboard')
            else:
                messages.error(request, 'Invalid credentials or insufficient permissions.')
    return render(request, 'wiki/login.html', {'form': form})


def logout_view(request):
    logout(request)
    return redirect('home')


def register_view(request):
    """Admin registration with email verification."""
    if request.user.is_authenticated:
        return redirect('admin_dashboard')

    form = RegisterForm()
    if request.method == 'POST':
        form = RegisterForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.is_active = False  # Inactive until email verified
            user.is_staff = True
            user.save()

            # Send verification email
            current_site = get_current_site(request)
            uid = urlsafe_base64_encode(force_bytes(user.pk))
            token = default_token_generator.make_token(user)
            verify_url = f"http://{current_site.domain}/verify-email/{uid}/{token}/"

            subject = 'Verify your Folio account'
            message = render_to_string('wiki/email/verify_email.txt', {
                'user': user,
                'verify_url': verify_url,
                'site_name': 'Folio',
            })
            send_mail(subject, message, 'noreply@folio.local', [user.email])

            messages.success(request, f'Account created! Check {user.email} for a verification link.')
            return redirect('login')

    return render(request, 'wiki/register.html', {'form': form})


def verify_email(request, uidb64, token):
    """Activate account after email link click."""
    try:
        uid = force_str(urlsafe_base64_decode(uidb64))
        user = User.objects.get(pk=uid)
    except (TypeError, ValueError, OverflowError, User.DoesNotExist):
        user = None

    if user is not None and default_token_generator.check_token(user, token):
        user.is_active = True
        user.save()
        login(request, user)
        messages.success(request, 'Email verified! Welcome to Folio 🎉')
        return redirect('admin_dashboard')
    else:
        messages.error(request, 'Verification link is invalid or has expired.')
        return redirect('login')


# ─── Admin: Pages ─────────────────────────────────────────────────────────────

@login_required
def admin_dashboard(request):
    pages = Page.objects.all().prefetch_related('categories').order_by('-updated_at')
    categories = Category.objects.all()
    published_count = pages.filter(status=Page.STATUS_PUBLISHED).count()
    draft_count = pages.filter(status=Page.STATUS_DRAFT).count()
    total_views = sum(p.view_count for p in pages)
    top_pages = pages.filter(status=Page.STATUS_PUBLISHED).order_by('-view_count')[:5]
    ctx = get_sidebar_context()
    ctx.update({
        'pages': pages,
        'categories': categories,
        'published_count': published_count,
        'draft_count': draft_count,
        'total_views': total_views,
        'top_pages': top_pages,
    })
    return render(request, 'wiki/admin_dashboard.html', ctx)


@login_required
def page_create(request):
    form = PageForm()
    if request.method == 'POST':
        form = PageForm(request.POST)
        if form.is_valid():
            page = form.save()
            messages.success(request, f'Page "{page.title}" created.')
            return redirect('admin_dashboard')
    ctx = get_sidebar_context()
    ctx.update({'form': form, 'action': 'Create', 'page': None})
    return render(request, 'wiki/page_form.html', ctx)


@login_required
def page_edit(request, slug):
    page = get_object_or_404(Page, slug=slug)
    form = PageForm(instance=page)
    if request.method == 'POST':
        form = PageForm(request.POST, instance=page)
        if form.is_valid():
            page = form.save()
            messages.success(request, f'Page "{page.title}" updated.')
            return redirect('admin_dashboard')
    ctx = get_sidebar_context()
    ctx.update({'form': form, 'action': 'Edit', 'page': page})
    return render(request, 'wiki/page_form.html', ctx)


@login_required
def page_delete(request, slug):
    page = get_object_or_404(Page, slug=slug)
    if request.method == 'POST':
        title = page.title
        page.delete()
        messages.success(request, f'Page "{title}" deleted.')
        return redirect('admin_dashboard')
    ctx = get_sidebar_context()
    ctx['page'] = page
    return render(request, 'wiki/page_confirm_delete.html', ctx)


@login_required
def page_toggle_status(request, slug):
    page = get_object_or_404(Page, slug=slug)
    if request.method == 'POST':
        if page.status == Page.STATUS_PUBLISHED:
            page.status = Page.STATUS_DRAFT
            messages.info(request, f'"{page.title}" moved to draft.')
        else:
            page.status = Page.STATUS_PUBLISHED
            messages.success(request, f'"{page.title}" published.')
        page.save()
    return redirect('admin_dashboard')


# ─── Admin: Categories ────────────────────────────────────────────────────────

@login_required
def category_create(request):
    form = CategoryForm()
    if request.method == 'POST':
        form = CategoryForm(request.POST)
        if form.is_valid():
            cat = form.save()
            messages.success(request, f'Category "{cat.name}" created.')
            return redirect('admin_dashboard')
    ctx = get_sidebar_context()
    ctx.update({'form': form, 'action': 'Create', 'category': None})
    return render(request, 'wiki/category_form.html', ctx)


@login_required
def category_edit(request, slug):
    category = get_object_or_404(Category, slug=slug)
    form = CategoryForm(instance=category)
    if request.method == 'POST':
        form = CategoryForm(request.POST, instance=category)
        if form.is_valid():
            cat = form.save()
            messages.success(request, f'Category updated.')
            return redirect('admin_dashboard')
    ctx = get_sidebar_context()
    ctx.update({'form': form, 'action': 'Edit', 'category': category})
    return render(request, 'wiki/category_form.html', ctx)


@login_required
def category_delete(request, slug):
    category = get_object_or_404(Category, slug=slug)
    if request.method == 'POST':
        name = category.name
        category.delete()
        messages.success(request, f'Category "{name}" deleted.')
        return redirect('admin_dashboard')
    ctx = get_sidebar_context()
    ctx['category'] = category
    return render(request, 'wiki/category_confirm_delete.html', ctx)
