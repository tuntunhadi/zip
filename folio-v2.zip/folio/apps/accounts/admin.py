from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User

@admin.register(User)
class CustomUserAdmin(UserAdmin):
    list_display = ['username', 'email', 'display_name', 'wiki_public', 'created_at']
    fieldsets = UserAdmin.fieldsets + (
        ('Folio', {'fields': ('display_name', 'bio', 'avatar', 'website', 'wiki_title', 'wiki_public', 'dark_mode')}),
    )
