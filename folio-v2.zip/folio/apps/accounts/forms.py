from django import forms
from allauth.account.forms import SignupForm
from .models import User

INPUT = (
    'w-full px-4 py-3 rounded-xl border bg-white dark:bg-zinc-900 '
    'border-zinc-200 dark:border-zinc-700 text-zinc-800 dark:text-zinc-100 '
    'placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 '
    'focus:border-transparent transition text-sm'
)

class CustomSignupForm(SignupForm):
    username = forms.CharField(
        max_length=30,
        min_length=3,
        widget=forms.TextInput(attrs={
            'class': INPUT,
            'placeholder': 'username',
            'autocomplete': 'username',
        })
    )

    def save(self, request):
        user = super().save(request)
        user.username = self.cleaned_data['username']
        user.save()
        return user

    def clean_username(self):
        username = self.cleaned_data['username'].lower().strip()
        if User.objects.filter(username=username).exists():
            raise forms.ValidationError('This username is already taken.')
        if not username.replace('_', '').replace('-', '').isalnum():
            raise forms.ValidationError('Username can only contain letters, numbers, _ and -')
        return username


class ProfileForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ['display_name', 'bio', 'avatar', 'website', 'wiki_title', 'wiki_public']
        widgets = {
            'display_name': forms.TextInput(attrs={'class': INPUT, 'placeholder': 'Your display name'}),
            'bio': forms.Textarea(attrs={'class': INPUT + ' resize-none', 'rows': 3, 'placeholder': 'Tell the world about yourself...'}),
            'website': forms.URLInput(attrs={'class': INPUT, 'placeholder': 'https://yoursite.com'}),
            'wiki_title': forms.TextInput(attrs={'class': INPUT, 'placeholder': "My Knowledge Base"}),
            'wiki_public': forms.CheckboxInput(attrs={'class': 'w-4 h-4 rounded text-indigo-500 border-zinc-300 focus:ring-indigo-500'}),
            'avatar': forms.FileInput(attrs={'class': 'hidden', 'id': 'avatar-input', 'accept': 'image/*'}),
        }
