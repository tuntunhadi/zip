from django.contrib.auth.models import AbstractUser
from django.db import models
from slugify import slugify


class User(AbstractUser):
    username = models.CharField(max_length=30, unique=True)
    email = models.EmailField(unique=True)
    display_name = models.CharField(max_length=60, blank=True)
    bio = models.TextField(max_length=300, blank=True)
    avatar = models.ImageField(upload_to='avatars/', blank=True, null=True)
    website = models.URLField(blank=True)
    wiki_title = models.CharField(max_length=100, blank=True, help_text='Custom title for your wiki')
    wiki_public = models.BooleanField(default=True)
    dark_mode = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['username']

    def __str__(self):
        return self.username

    def get_wiki_title(self):
        return self.wiki_title or f"{self.username}'s Wiki"

    def get_avatar_url(self):
        if self.avatar:
            return self.avatar.url
        # Generate initials avatar fallback
        return None
