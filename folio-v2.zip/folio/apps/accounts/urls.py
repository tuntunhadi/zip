from django.urls import path
from . import views

urlpatterns = [
    path('', views.landing, name='landing'),
    path('onboarding/', views.onboarding, name='onboarding'),
    path('settings/', views.settings_view, name='settings'),
    path('explore/', views.explore, name='explore'),
    path('toggle-dark/', views.toggle_dark_mode, name='toggle_dark_mode'),
    path('u/<str:username>/', views.profile, name='profile'),
]
