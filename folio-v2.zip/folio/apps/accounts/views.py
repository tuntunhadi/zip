from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import JsonResponse
from .models import User
from .forms import ProfileForm
from apps.wiki.models import Page, Category


def landing(request):
    if request.user.is_authenticated:
        return redirect('wiki:home', username=request.user.username)
    return render(request, 'landing.html')


def profile(request, username):
    profile_user = get_object_or_404(User, username=username)
    pages = Page.objects.filter(
        author=profile_user,
        status=Page.STATUS_PUBLISHED
    ).prefetch_related('categories').order_by('-updated_at')[:10]
    return render(request, 'accounts/profile.html', {
        'profile_user': profile_user,
        'pages': pages,
    })


@login_required
def onboarding(request):
    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Profile saved! Welcome to Folio 🎉')
            return redirect('wiki:home', username=request.user.username)
    else:
        form = ProfileForm(instance=request.user)
    return render(request, 'accounts/onboarding.html', {'form': form})


@login_required
def settings_view(request):
    if request.method == 'POST':
        form = ProfileForm(request.POST, request.FILES, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, 'Settings updated.')
            return redirect('settings')
    else:
        form = ProfileForm(instance=request.user)
    return render(request, 'accounts/settings.html', {'form': form})


@login_required
def toggle_dark_mode(request):
    if request.method == 'POST':
        request.user.dark_mode = not request.user.dark_mode
        request.user.save()
        return JsonResponse({'dark_mode': request.user.dark_mode})
    return JsonResponse({'error': 'POST required'}, status=400)


def explore(request):
    users = User.objects.filter(wiki_public=True).order_by('-created_at')[:20]
    recent_pages = Page.objects.filter(
        status=Page.STATUS_PUBLISHED,
        author__wiki_public=True
    ).select_related('author').prefetch_related('categories').order_by('-updated_at')[:20]
    return render(request, 'accounts/explore.html', {
        'users': users,
        'recent_pages': recent_pages,
    })
