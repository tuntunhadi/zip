from django.contrib import admin
from .models import Page, Category

@admin.register(Page)
class PageAdmin(admin.ModelAdmin):
    list_display = ['title', 'author', 'status', 'updated_at']
    list_filter = ['status']

@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ['name', 'owner', 'color']
