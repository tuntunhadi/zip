from django import forms
from slugify import slugify
from .models import Page, Category

INPUT = (
    'w-full px-4 py-2.5 rounded-xl border border-zinc-200 dark:border-zinc-700 '
    'bg-white dark:bg-zinc-900 text-zinc-800 dark:text-zinc-100 '
    'placeholder-zinc-400 focus:outline-none focus:ring-2 focus:ring-indigo-500 '
    'focus:border-transparent transition text-sm'
)


class CategoryForm(forms.ModelForm):
    class Meta:
        model = Category
        fields = ['name', 'slug', 'color']
        widgets = {
            'name': forms.TextInput(attrs={'class': INPUT, 'placeholder': 'Category name...'}),
            'slug': forms.TextInput(attrs={'class': INPUT + ' font-mono', 'placeholder': 'auto-generated'}),
            'color': forms.TextInput(attrs={'type': 'color', 'class': 'w-12 h-10 rounded-lg border border-zinc-200 cursor-pointer p-1 bg-white'}),
        }

    def clean_slug(self):
        slug = self.cleaned_data.get('slug', '')
        name = self.cleaned_data.get('name', '')
        return slugify(slug) if slug else slugify(name)


class PageForm(forms.ModelForm):
    categories = forms.ModelMultipleChoiceField(
        queryset=Category.objects.none(),
        required=False,
        widget=forms.CheckboxSelectMultiple,
    )

    class Meta:
        model = Page
        fields = ['title', 'slug', 'content', 'status', 'categories']
        widgets = {
            'title': forms.TextInput(attrs={'class': INPUT + ' font-medium text-base', 'placeholder': 'Page title...'}),
            'slug': forms.TextInput(attrs={'class': INPUT + ' font-mono', 'placeholder': 'auto-generated-from-title'}),
            'status': forms.Select(attrs={'class': 'px-3 py-2.5 rounded-xl border border-zinc-200 dark:border-zinc-700 bg-white dark:bg-zinc-900 text-zinc-800 dark:text-zinc-100 focus:outline-none focus:ring-2 focus:ring-indigo-500 transition text-sm'}),
            'content': forms.Textarea(attrs={'id': 'markdown-editor', 'rows': 20, 'class': 'w-full'}),
        }

    def __init__(self, *args, user=None, **kwargs):
        super().__init__(*args, **kwargs)
        if user:
            self.fields['categories'].queryset = Category.objects.filter(owner=user)

    def clean_slug(self):
        slug = self.cleaned_data.get('slug', '')
        title = self.cleaned_data.get('title', '')
        return slugify(slug) if slug else slugify(title)
