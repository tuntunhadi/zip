from django.urls import path
from . import views

app_name = 'wiki'

urlpatterns = [
    # Public
    path('<str:username>/', views.wiki_home, name='home'),
    path('<str:username>/p/<slug:slug>/', views.wiki_page, name='page'),

    # Dashboard
    path('~dashboard/', views.wiki_dashboard, name='dashboard'),
    path('~create/', views.page_create, name='page_create'),
    path('~edit/<slug:slug>/', views.page_edit, name='page_edit'),
    path('~delete/<slug:slug>/', views.page_delete, name='page_delete'),
    path('~toggle/<slug:slug>/', views.page_toggle_status, name='page_toggle'),
    path('~categories/create/', views.category_create, name='category_create'),
    path('~categories/edit/<slug:slug>/', views.category_edit, name='category_edit'),
    path('~categories/delete/<slug:slug>/', views.category_delete, name='category_delete'),
]
