from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from apps.accounts.models import User
from .models import Page, Category
from .forms import PageForm, CategoryForm


def get_wiki_sidebar(owner):
    return {
        'wiki_owner': owner,
        'sidebar_pages': Page.objects.filter(author=owner, status=Page.STATUS_PUBLISHED).order_by('title'),
        'sidebar_categories': Category.objects.filter(owner=owner),
    }


# ── Public wiki views ──────────────────────────────────────────────────────────

def wiki_home(request, username):
    owner = get_object_or_404(User, username=username)
    if not owner.wiki_public and request.user != owner:
        return render(request, 'wiki/private.html', {'wiki_owner': owner})

    query = request.GET.get('q', '').strip()
    cat_slug = request.GET.get('cat', '').strip()

    pages = Page.objects.filter(author=owner, status=Page.STATUS_PUBLISHED).prefetch_related('categories')
    if query:
        pages = pages.filter(Q(title__icontains=query) | Q(content__icontains=query))

    current_category = None
    if cat_slug:
        current_category = get_object_or_404(Category, slug=cat_slug, owner=owner)
        pages = pages.filter(categories=current_category)

    ctx = get_wiki_sidebar(owner)
    ctx.update({'pages': pages, 'query': query, 'current_category': current_category})
    return render(request, 'wiki/home.html', ctx)


def wiki_page(request, username, slug):
    owner = get_object_or_404(User, username=username)
    if not owner.wiki_public and request.user != owner:
        return render(request, 'wiki/private.html', {'wiki_owner': owner})
    page = get_object_or_404(Page, slug=slug, author=owner, status=Page.STATUS_PUBLISHED)
    ctx = get_wiki_sidebar(owner)
    ctx['page'] = page
    return render(request, 'wiki/page_detail.html', ctx)


# ── Admin wiki views ───────────────────────────────────────────────────────────

@login_required
def wiki_dashboard(request):
    pages = Page.objects.filter(author=request.user).prefetch_related('categories').order_by('-updated_at')
    categories = Category.objects.filter(owner=request.user)
    ctx = get_wiki_sidebar(request.user)
    ctx.update({
        'pages': pages,
        'categories': categories,
        'published_count': pages.filter(status=Page.STATUS_PUBLISHED).count(),
        'draft_count': pages.filter(status=Page.STATUS_DRAFT).count(),
    })
    return render(request, 'wiki/dashboard.html', ctx)


@login_required
def page_create(request):
    form = PageForm(user=request.user)
    if request.method == 'POST':
        form = PageForm(request.POST, user=request.user)
        if form.is_valid():
            page = form.save(commit=False)
            page.author = request.user
            page.save()
            form.save_m2m()
            messages.success(request, f'Page "{page.title}" created.')
            return redirect('wiki:dashboard')
    ctx = get_wiki_sidebar(request.user)
    ctx.update({'form': form, 'action': 'Create', 'page': None})
    return render(request, 'wiki/page_form.html', ctx)


@login_required
def page_edit(request, slug):
    page = get_object_or_404(Page, slug=slug, author=request.user)
    form = PageForm(instance=page, user=request.user)
    if request.method == 'POST':
        form = PageForm(request.POST, instance=page, user=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, f'Page "{page.title}" updated.')
            return redirect('wiki:dashboard')
    ctx = get_wiki_sidebar(request.user)
    ctx.update({'form': form, 'action': 'Edit', 'page': page})
    return render(request, 'wiki/page_form.html', ctx)


@login_required
def page_delete(request, slug):
    page = get_object_or_404(Page, slug=slug, author=request.user)
    if request.method == 'POST':
        page.delete()
        messages.success(request, f'Page deleted.')
        return redirect('wiki:dashboard')
    ctx = get_wiki_sidebar(request.user)
    ctx['page'] = page
    return render(request, 'wiki/page_confirm_delete.html', ctx)


@login_required
def page_toggle_status(request, slug):
    page = get_object_or_404(Page, slug=slug, author=request.user)
    if request.method == 'POST':
        page.status = Page.STATUS_DRAFT if page.is_published() else Page.STATUS_PUBLISHED
        page.save()
        messages.success(request, f'"{page.title}" is now {page.status}.')
    return redirect('wiki:dashboard')


@login_required
def category_create(request):
    form = CategoryForm()
    if request.method == 'POST':
        form = CategoryForm(request.POST)
        if form.is_valid():
            cat = form.save(commit=False)
            cat.owner = request.user
            cat.save()
            messages.success(request, f'Category "{cat.name}" created.')
            return redirect('wiki:dashboard')
    ctx = get_wiki_sidebar(request.user)
    ctx.update({'form': form, 'action': 'Create', 'category': None})
    return render(request, 'wiki/category_form.html', ctx)


@login_required
def category_edit(request, slug):
    category = get_object_or_404(Category, slug=slug, owner=request.user)
    form = CategoryForm(instance=category)
    if request.method == 'POST':
        form = CategoryForm(request.POST, instance=category)
        if form.is_valid():
            form.save()
            messages.success(request, f'Category updated.')
            return redirect('wiki:dashboard')
    ctx = get_wiki_sidebar(request.user)
    ctx.update({'form': form, 'action': 'Edit', 'category': category})
    return render(request, 'wiki/category_form.html', ctx)


@login_required
def category_delete(request, slug):
    category = get_object_or_404(Category, slug=slug, owner=request.user)
    if request.method == 'POST':
        category.delete()
        messages.success(request, 'Category deleted.')
        return redirect('wiki:dashboard')
    ctx = get_wiki_sidebar(request.user)
    ctx['category'] = category
    return render(request, 'wiki/category_confirm_delete.html', ctx)
