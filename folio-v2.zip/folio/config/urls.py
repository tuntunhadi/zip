from django.contrib import admin
from django.urls import path, include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('django-admin/', admin.site.urls),
    path('accounts/', include('allauth.urls')),
    path('', include('apps.accounts.urls')),
    path('wiki/', include('apps.wiki.urls')),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
