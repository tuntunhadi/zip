#!/bin/bash
echo ""
echo "  📚 Folio — Setup"
echo "─────────────────────────────────────"
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt --quiet
python manage.py migrate
echo ""
echo "  Create your Admin account"
echo "─────────────────────────────────────"
python manage.py createsuperuser
echo ""
echo "  ✅ Done! Run with:"
echo "  source venv/bin/activate"
echo "  python manage.py runserver"
echo "  Then open: http://127.0.0.1:8000"
echo "─────────────────────────────────────"
