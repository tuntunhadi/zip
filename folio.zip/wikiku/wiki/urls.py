from django.urls import path
from . import views

urlpatterns = [
    # Public
    path('', views.home, name='home'),
    path('page/<slug:slug>/', views.page_detail, name='page_detail'),
    path('category/<slug:slug>/', views.category_detail, name='category_detail'),

    # Auth
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),

    # Admin — Pages
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
    path('admin-dashboard/create/', views.page_create, name='page_create'),
    path('admin-dashboard/edit/<slug:slug>/', views.page_edit, name='page_edit'),
    path('admin-dashboard/delete/<slug:slug>/', views.page_delete, name='page_delete'),
    path('admin-dashboard/toggle/<slug:slug>/', views.page_toggle_status, name='page_toggle_status'),

    # Admin — Categories
    path('admin-dashboard/categories/create/', views.category_create, name='category_create'),
    path('admin-dashboard/categories/edit/<slug:slug>/', views.category_edit, name='category_edit'),
    path('admin-dashboard/categories/delete/<slug:slug>/', views.category_delete, name='category_delete'),
]
