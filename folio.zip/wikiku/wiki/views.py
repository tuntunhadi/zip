from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from slugify import slugify

from .models import Page, Category
from .forms import PageForm, CategoryForm, LoginForm


# ─── Helpers ──────────────────────────────────────────────────────────────────

def get_sidebar_context():
    return {
        'all_pages': Page.objects.filter(status=Page.STATUS_PUBLISHED).order_by('title'),
        'all_categories': Category.objects.all(),
    }


# ─── Public Views ─────────────────────────────────────────────────────────────

def home(request):
    query = request.GET.get('q', '').strip()
    active_cat = request.GET.get('cat', '').strip()

    pages = Page.objects.filter(status=Page.STATUS_PUBLISHED).prefetch_related('categories')

    if query:
        pages = pages.filter(
            Q(title__icontains=query) | Q(content__icontains=query)
        )

    current_category = None
    if active_cat:
        current_category = get_object_or_404(Category, slug=active_cat)
        pages = pages.filter(categories=current_category)

    ctx = get_sidebar_context()
    ctx.update({
        'pages': pages,
        'query': query,
        'current_category': current_category,
    })
    return render(request, 'wiki/home.html', ctx)


def page_detail(request, slug):
    page = get_object_or_404(Page, slug=slug, status=Page.STATUS_PUBLISHED)
    ctx = get_sidebar_context()
    ctx['page'] = page
    return render(request, 'wiki/page_detail.html', ctx)


def category_detail(request, slug):
    category = get_object_or_404(Category, slug=slug)
    pages = Page.objects.filter(
        status=Page.STATUS_PUBLISHED, categories=category
    ).prefetch_related('categories')
    ctx = get_sidebar_context()
    ctx.update({'category': category, 'pages': pages})
    return render(request, 'wiki/category_detail.html', ctx)


# ─── Auth Views ───────────────────────────────────────────────────────────────

def login_view(request):
    if request.user.is_authenticated:
        return redirect('admin_dashboard')
    form = LoginForm()
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            user = authenticate(
                request,
                username=form.cleaned_data['username'],
                password=form.cleaned_data['password'],
            )
            if user is not None and user.is_staff:
                login(request, user)
                return redirect('admin_dashboard')
            else:
                messages.error(request, 'Invalid credentials or insufficient permissions.')
    return render(request, 'wiki/login.html', {'form': form})


def logout_view(request):
    logout(request)
    return redirect('home')


# ─── Admin: Pages ─────────────────────────────────────────────────────────────

@login_required
def admin_dashboard(request):
    pages = Page.objects.all().prefetch_related('categories').order_by('-updated_at')
    categories = Category.objects.all()
    published_count = pages.filter(status=Page.STATUS_PUBLISHED).count()
    draft_count = pages.filter(status=Page.STATUS_DRAFT).count()
    return render(request, 'wiki/admin_dashboard.html', {
        'pages': pages,
        'categories': categories,
        'published_count': published_count,
        'draft_count': draft_count,
    })


@login_required
def page_create(request):
    form = PageForm()
    if request.method == 'POST':
        form = PageForm(request.POST)
        if form.is_valid():
            page = form.save()
            messages.success(request, f'Page "{page.title}" created.')
            return redirect('admin_dashboard')
    return render(request, 'wiki/page_form.html', {
        'form': form, 'action': 'Create', 'page': None,
    })


@login_required
def page_edit(request, slug):
    page = get_object_or_404(Page, slug=slug)
    form = PageForm(instance=page)
    if request.method == 'POST':
        form = PageForm(request.POST, instance=page)
        if form.is_valid():
            page = form.save()
            messages.success(request, f'Page "{page.title}" updated.')
            return redirect('admin_dashboard')
    return render(request, 'wiki/page_form.html', {
        'form': form, 'action': 'Edit', 'page': page,
    })


@login_required
def page_delete(request, slug):
    page = get_object_or_404(Page, slug=slug)
    if request.method == 'POST':
        title = page.title
        page.delete()
        messages.success(request, f'Page "{title}" deleted.')
        return redirect('admin_dashboard')
    return render(request, 'wiki/page_confirm_delete.html', {'page': page})


@login_required
def page_toggle_status(request, slug):
    page = get_object_or_404(Page, slug=slug)
    if request.method == 'POST':
        if page.status == Page.STATUS_PUBLISHED:
            page.status = Page.STATUS_DRAFT
            messages.info(request, f'"{page.title}" moved to draft.')
        else:
            page.status = Page.STATUS_PUBLISHED
            messages.success(request, f'"{page.title}" published.')
        page.save()
    return redirect('admin_dashboard')


# ─── Admin: Categories ────────────────────────────────────────────────────────

@login_required
def category_create(request):
    form = CategoryForm()
    if request.method == 'POST':
        form = CategoryForm(request.POST)
        if form.is_valid():
            cat = form.save()
            messages.success(request, f'Category "{cat.name}" created.')
            return redirect('admin_dashboard')
    return render(request, 'wiki/category_form.html', {
        'form': form, 'action': 'Create', 'category': None,
    })


@login_required
def category_edit(request, slug):
    category = get_object_or_404(Category, slug=slug)
    form = CategoryForm(instance=category)
    if request.method == 'POST':
        form = CategoryForm(request.POST, instance=category)
        if form.is_valid():
            cat = form.save()
            messages.success(request, f'Category "{cat.name}" updated.')
            return redirect('admin_dashboard')
    return render(request, 'wiki/category_form.html', {
        'form': form, 'action': 'Edit', 'category': category,
    })


@login_required
def category_delete(request, slug):
    category = get_object_or_404(Category, slug=slug)
    if request.method == 'POST':
        name = category.name
        category.delete()
        messages.success(request, f'Category "{name}" deleted.')
        return redirect('admin_dashboard')
    return render(request, 'wiki/category_confirm_delete.html', {'category': category})
