
from django.db import models
from django.utils.text import slugify

class Page(models.Model):

    STATUS_CHOICES = [
        ("draft","Draft"),
        ("published","Published"),
    ]

    title = models.CharField(max_length=255)
    slug = models.SlugField(unique=True, blank=True)
    content = models.TextField()

    status = models.CharField(
        max_length=10,
        choices=STATUS_CHOICES,
        default="draft"
    )

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def save(self,*args,**kwargs):
        if not self.slug:
            self.slug = slugify(self.title)

        base_slug = self.slug
        counter = 1
        while Page.objects.filter(slug=self.slug).exclude(id=self.id).exists():
            self.slug = f"{base_slug}-{counter}"
            counter += 1

        super().save(*args,**kwargs)

    def __str__(self):
        return self.title
