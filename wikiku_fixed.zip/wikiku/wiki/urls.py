
from django.urls import path
from . import views

urlpatterns = [
    path("",views.home,name="home"),
    path("login/",views.login_view,name="login"),
    path("logout/",views.logout_view,name="logout"),
    path("dashboard/",views.dashboard,name="dashboard"),
    path("create/",views.page_create,name="create"),
    path("page/<slug:slug>/",views.page_detail,name="page"),
    path("delete/<slug:slug>/",views.page_delete,name="delete"),
]
