
from django.shortcuts import render,redirect,get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth import authenticate,login,logout
from .models import Page
from .forms import PageForm

def home(request):
    pages = Page.objects.filter(status="published")
    return render(request,"wiki/home.html",{"pages":pages})

def page_detail(request,slug):
    page = get_object_or_404(Page,slug=slug,status="published")
    return render(request,"wiki/page_detail.html",{"page":page})

@login_required
def dashboard(request):
    pages = Page.objects.all().order_by("-created_at")
    return render(request,"wiki/admin_dashboard.html",{"pages":pages})

@login_required
def page_create(request):
    if request.method == "POST":
        form = PageForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("dashboard")
    else:
        form = PageForm()

    return render(request,"wiki/page_form.html",{"form":form})

@login_required
def page_delete(request,slug):
    page = get_object_or_404(Page,slug=slug)
    if request.method == "POST":
        page.delete()
        return redirect("dashboard")

    return render(request,"wiki/page_confirm_delete.html",{"page":page})

def login_view(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        user = authenticate(request,username=username,password=password)

        if user:
            login(request,user)
            return redirect("dashboard")

    return render(request,"wiki/login.html")

def logout_view(request):
    logout(request)
    return redirect("home")
